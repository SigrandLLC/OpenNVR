#! /bin/sh
${srcdir}/out_test.sh rdf_test modules/objfmts/rdf/tests "rdf objfmt" "-f rdf" ".rdf"
exit $?
